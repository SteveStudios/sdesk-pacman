---
name: Feature request
about: Suggest an idea for this project
title: ""
labels: "Type: Feature Request, Status: Discussion Open"
assignees: ""
---

### Is your feature request related to a problem? Please describe.

<!-- A clear and concise description of the problem, e.g. I'm always frustrated when ... -->

### Describe the solution you'd like

<!-- A clear and concise description of what you want to happen. -->

### Describe alternatives you've considered

<!-- A clear and concise description of any alternative solutions or features you've considered. -->

### Additional context

<!-- Add any other context or screenshots about the feature request here. -->
